/*
CSE 390
This main program uses the linkedlist.

To compile:
gcc -c linkedlist.c
gcc -c use_linkedlist.c
gcc -o ll linkedlist.o use_linkedlist.o
*/

#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"

int main(void) {
    Node* front = (Node*) calloc(1, sizeof(Node));
    front->data = 10;
    front->next = (Node*) calloc(1, sizeof(Node));
    front->next->data = 20;
    front->next->next = (Node*) calloc(1, sizeof(Node));
    front->next->next->data = 30;
    front->next->next->next = NULL;
    
    printf("booyah\n");
    ll_print(front);
    printf("%d\n", ll_sum(front));
    
    return 0;
}
