/*
CSE 390
Implementation of integer linked list functions.

To compile:
gcc -c linkedlist.c
*/


#include <stdio.h>
#include "linkedlist.h"

void ll_print(Node* front) {
    while (front) {
        printf("%d\t", front->data);
        front = front->next;
    }
    printf("\n");
}

int ll_sum(Node* front) {
    int sum = 0;
    while (front) {
        sum += front->data;
        front = front->next;
    }
    return sum;
}
