// I wrote this program late, but I will change it
// so it looks like I wrote it early!  Hee, hee.

public class MyProgram {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }
}
